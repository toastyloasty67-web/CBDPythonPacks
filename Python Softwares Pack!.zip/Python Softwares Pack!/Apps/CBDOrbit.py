import tkinter as tk
import math
import random
import os

class CBDOrbit:
    def __init__(self, root):
        self.root = root
        self.root.title("CBDOrbit")
        self.root.geometry("1100x850")
        self.root.configure(bg="#050505")

        user_name = os.getlogin()
        self.asset_path = rf"C:\Users\{user_name}\Desktop\Python Softwares Pack!\Assets\pixil-frame-0.png"

        # --- High-Performance State ---
        self.G = 0.6             
        self.sun_mass = 7500     
        self.planets = []        
        
        # Performance Variables
        self.collisions_enabled = tk.BooleanVar(value=True)
        self.spatial_culling = tk.BooleanVar(value=True) # Logic Optimization
        self.target_fps = tk.IntVar(value=16) 
        self.auto_orbit = tk.BooleanVar(value=False)
        self.planet_count = tk.StringVar(value="Planets: 0")

        self.setup_ui()
        self.setup_splash_screen()
        self.update_physics()

    def setup_ui(self):
        self.canvas = tk.Canvas(self.root, bg="#000008", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.sun_x, self.sun_y = 550, 425
        self.canvas.create_oval(self.sun_x-22, self.sun_y-22, self.sun_x+22, self.sun_y+22, 
                                 fill="#ffcc00", outline="#ffaa00", width=3)
        
        # HUD
        hud = tk.Frame(self.root, bg="#111", width=200)
        hud.place(x=10, y=10)
        tk.Label(hud, text="CBD-ORBIT", fg="#00FFCC", bg="#111", font=("Impact", 20)).pack(pady=10, padx=10)
        
        # Live Stats
        tk.Label(hud, textvariable=self.planet_count, fg="white", bg="#111").pack(pady=2)
        
        tk.Button(hud, text="⚙️ PERFORMANCE", bg="#444", fg="white", relief="flat",
                  command=self.open_options).pack(fill="x", padx=10, pady=5)
        
        tk.Button(hud, text="🗑 WIPE ALL", bg="#e74c3c", fg="white", relief="flat",
                  command=self.clear_space).pack(fill="x", padx=10, pady=5)

        self.canvas.bind("<Button-1>", self.start_launch)
        self.canvas.bind("<B1-Motion>", self.drag_launch)
        self.canvas.bind("<ButtonRelease-1>", self.end_launch)

    def open_options(self):
        opt_win = tk.Toplevel(self.root)
        opt_win.title("Engine Config")
        opt_win.geometry("350x450")
        opt_win.configure(bg="#1a1a1a")

        tk.Label(opt_win, text="ENGINE OPTIMIZATION", fg="#00FFCC", bg="#1a1a1a", font=("Arial", 12, "bold")).pack(pady=15)

        # 1. Physics Engine Choice
        tk.Checkbutton(opt_win, text="Enable Inter-Planet Gravity", variable=self.collisions_enabled,
                       bg="#1a1a1a", fg="white", selectcolor="#000").pack(anchor="w", padx=30, pady=5)

        # 2. Spatial Culling (New)
        tk.Checkbutton(opt_win, text="Spatial Culling (Ignore distant objects)", variable=self.spatial_culling,
                       bg="#1a1a1a", fg="white", selectcolor="#000").pack(anchor="w", padx=30, pady=5)

        # 3. Physics Tick Rate
        tk.Label(opt_win, text="Physics Tick Rate (Lower = Smoother)", fg="gray", bg="#1a1a1a").pack(pady=(15, 0))
        tk.Scale(opt_win, variable=self.target_fps, from_=8, to=60, orient="horizontal",
                 bg="#1a1a1a", fg="white", highlightthickness=0).pack(fill="x", padx=40)

        tk.Button(opt_win, text="SAVE SETTINGS", bg="#00FFCC", fg="black", command=opt_win.destroy).pack(pady=30)

    def update_physics(self):
        planets_to_kill = set()
        
        # Update Counter
        self.planet_count.set(f"Planets: {len(self.planets)}")

        # Calculate limits for Spatial Culling
        # 
        win_w = self.root.winfo_width()
        win_h = self.root.winfo_height()

        for i in range(len(self.planets)):
            if i in planets_to_kill: continue
            p1 = self.planets[i]
            
            # --- Spatial Culling Optimization ---
            if self.spatial_culling.get():
                if p1['x'] < -500 or p1['x'] > win_w + 500 or p1['y'] < -500 or p1['y'] > win_h + 500:
                    planets_to_kill.add(i)
                    continue

            # Gravity Math
            dx, dy = self.sun_x - p1['x'], self.sun_y - p1['y']
            dist_sq = dx**2 + dy**2
            dist = math.sqrt(dist_sq)

            # Crash into sun check
            if dist < 28:
                planets_to_kill.add(i)
                continue

            # Core Gravitation formula
            # 



            force = (self.G * self.sun_mass) / dist_sq
            p1['vx'] += force * (dx / dist)
            p1['vy'] += force * (dy / dist)

            # Collision Logic
            if self.collisions_enabled.get():
                for j in range(i + 1, len(self.planets)):
                    if j in planets_to_kill: continue
                    p2 = self.planets[j]
                    pdx, pdy = p1['x'] - p2['x'], p1['y'] - p2['y']
                    p_dist_sq = pdx**2 + pdy**2 # Avoid sqrt for performance
                    
                    if p_dist_sq < (p1['radius'] + p2['radius'])**2:
                        planets_to_kill.add(i)
                        planets_to_kill.add(j)
                        break

        # Batch UI Update (Moving all objects in one frame)
        active_planets = []
        for i, p in enumerate(self.planets):
            if i in planets_to_kill:
                self.canvas.delete(p['id'])
            else:
                p['x'] += p['vx']
                p['y'] += p['vy']
                r = p['radius']
                self.canvas.coords(p['id'], p['x']-r, p['y']-r, p['x']+r, p['y']+r)
                active_planets.append(p)

        self.planets = active_planets
        self.root.after(self.target_fps.get(), self.update_physics)

    def setup_splash_screen(self):
        self.splash = tk.Canvas(self.root, bg="#000", highlightthickness=0)
        self.splash.place(x=0, y=0, relwidth=1, relheight=1)
        if os.path.exists(self.asset_path):
            try:
                self.logo = tk.PhotoImage(file=self.asset_path)
                self.splash.create_image(550, 425, image=self.logo)
            except: pass
        self.root.after(1200, self.splash.destroy)

    def start_launch(self, event):
        self.launch_start = (event.x, event.y)
        self.preview = self.canvas.create_line(event.x, event.y, event.x, event.y, fill="#00FFCC", dash=(4,4))

    def drag_launch(self, event):
        self.canvas.coords(self.preview, self.launch_start[0], self.launch_start[1], event.x, event.y)

    def end_launch(self, event):
        self.canvas.delete(self.preview)
        px, py = self.launch_start
        
        if self.auto_orbit.get():
            dx, dy = self.sun_x - px, self.sun_y - py
            dist = math.sqrt(dx**2 + dy**2)
            v_mag = math.sqrt((self.G * self.sun_mass) / dist)
            vx, vy = (dy / dist) * v_mag, (-dx / dist) * v_mag
        else:
            vx, vy = (px - event.x) / 10, (py - event.y) / 10
        
        color = random.choice(["#3498db", "#e74c3c", "#2ecc71", "#f1c40f", "#9b59b6"])
        r = 6
        p_id = self.canvas.create_oval(px-r, py-r, px+r, py+r, fill=color, outline="white")
        self.planets.append({'id': p_id, 'x': px, 'y': py, 'vx': vx, 'vy': vy, 'color': color, 'radius': r})

    def clear_space(self):
        for p in self.planets: self.canvas.delete(p['id'])
        self.planets = []

if __name__ == "__main__":
    root = tk.Tk()
    app = CBDOrbit(root)
    root.mainloop()