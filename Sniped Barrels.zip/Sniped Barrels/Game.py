import tkinter as tk
import random
import math
import os
import base64
import getpass

class SniperGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Sniped Barreled")
        self.width = 800
        self.height = 600
        
        # Save System (Encrpyted)
        # Using getpass.getuser() to dynamically resolve the local PC username
        username = getpass.getuser()
        self.save_dir = f"C:/Users/{username}/Desktop/Sniped Barrels/Save Data"
        self.save_file = os.path.join(self.save_dir, "system_data.bin")
        
        # Ensure the directory exists
        try:
            if not os.path.exists(self.save_dir):
                os.makedirs(self.save_dir)
        except Exception as e:
            print(f"Could not create save directory: {e}")
            # Fallback to local directory if desktop path fails
            self.save_file = "system_data.bin"

        self.high_score = self.load_high_score()
        
        # Game State
        self.score = 0
        self.level = 1
        self.barrels_left = 0
        self.is_game_over = False
        self.recoil_offset = 0
        self.time_left = 0
        self.wind_force = 0
        self.mouse_x = self.width / 2
        self.mouse_y = self.height / 2
        self.frame_count = 0
        self.loop_id = None
        self.timer_id = None
        
        # Setup Canvas
        self.canvas = tk.Canvas(root, width=self.width, height=self.height, bg="#020202", highlightthickness=0)
        self.canvas.pack()
        
        # Hide default cursor
        self.canvas.config(cursor="none")
        
        # Objects storage
        self.barrels = []
        self.smoke_particles = []
        
        # Bindings
        self.canvas.bind("<Motion>", self.track_mouse)
        self.canvas.bind("<Button-1>", self.shoot)
        self.root.bind("<r>", lambda e: self.reset_game())
        
        # Auto-save on exit
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        self.start_level()
        self.game_loop()
        self.countdown()

    def _xor_cipher(self, data):
        """Simple XOR cipher using a hardcoded key for obfuscation."""
        key = "SNIPER_SECRET_KEY_99"
        return "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))

    def load_high_score(self):
        """Loads and decrypts the high score."""
        if os.path.exists(self.save_file):
            try:
                with open(self.save_file, "rb") as f:
                    encoded_data = f.read()
                    # Decode from base64 then XOR decrypt
                    decrypted = self._xor_cipher(base64.b64decode(encoded_data).decode())
                    return int(decrypted)
            except Exception as e:
                print(f"Save corrupt, resetting: {e}")
                return 0
        return 0

    def save_high_score(self):
        """Encrypts and saves the current score if it's a new high score."""
        current_top = max(self.score, self.high_score)
        self.high_score = current_top
        try:
            # XOR encrypt then encode to base64
            encrypted = self._xor_cipher(str(current_top))
            encoded_data = base64.b64encode(encrypted.encode())
            with open(self.save_file, "wb") as f:
                f.write(encoded_data)
        except Exception as e:
            print(f"Save failed: {e}")

    def on_close(self):
        """Callback for window closure to ensure data is saved."""
        self.save_high_score()
        self.root.destroy()

    def start_level(self):
        """Initialize a new level with extreme challenges."""
        self.barrels_left = 8 + (self.level * 2)
        self.time_left = max(3, 10 - (self.level // 3)) 
        self.wind_force = random.uniform(-4.5, 4.5) * (1 + self.level * 0.3)
        
        self.canvas.delete("target")
        self.canvas.delete("smoke")
        self.barrels = []
        self.smoke_particles = []
        
        for _ in range(self.barrels_left):
            self.spawn_barrel()
            
        for _ in range(6):
            self.spawn_smoke()
            
        self.update_ui()

    def spawn_barrel(self):
        """Creates an armored, camouflaged barrel."""
        x = random.randint(100, self.width - 100)
        y = random.randint(100, self.height - 100)
        radius = max(5, 18 - self.level) 
        
        speed_factor = 3.0 + (self.level * 0.8)
        dx = random.choice([-1, 1]) * random.uniform(1.5, speed_factor)
        dy = random.choice([-1, 1]) * random.uniform(1.5, speed_factor)
        
        max_hp = min(5, 1 + (self.level // 2))
        hp = random.randint(1, max_hp)
        
        color = self.get_barrel_color(hp)
        
        body = self.canvas.create_rectangle(
            x - radius, y - radius * 1.5, 
            x + radius, y + radius * 1.5, 
            fill=color, outline="#000", width=1, tags="target"
        )
        
        self.barrels.append({
            "id": body, "x": x, "y": y, "dx": dx, "dy": dy,
            "r": radius, "hp": hp, "phase": random.uniform(0, math.pi * 2),
        })

    def spawn_smoke(self):
        sx = random.randint(0, self.width)
        sy = random.randint(0, self.height)
        size = random.randint(120, 280)
        cloud = self.canvas.create_oval(
            sx-size, sy-size, sx+size, sy+size, 
            fill="#121212", outline="", tags="smoke", stipple="gray25"
        )
        self.smoke_particles.append({
            "id": cloud, "x": sx, "y": sy, "dx": random.uniform(-0.8, 0.8), "size": size
        })

    def get_barrel_color(self, hp):
        c_val = max(5, 140 - (self.level * 12))
        if hp >= 5: return "#330000" # Ultra Heavy
        if hp == 4: return f"#{c_val//5:02x}{c_val//5:02x}{c_val//5:02x}" 
        if hp == 3: return "#1a252f" 
        if hp == 2: return "#555b5c" 
        return "#b03020" 

    def track_mouse(self, event):
        self.mouse_x = event.x
        self.mouse_y = event.y

    def update_crosshair(self):
        self.canvas.delete("crosshair")
        if self.is_game_over: return
        
        self.frame_count += 1
        # Sway intensity
        sway_x = math.sin(self.frame_count * 0.07) * 7
        sway_y = math.cos(self.frame_count * 0.12) * 4
        
        drift_x = self.mouse_x + (self.wind_force * 14) + sway_x
        drift_y = self.mouse_y - self.recoil_offset + sway_y
        
        color = "#ff3300"
        self.canvas.create_oval(drift_x-45, drift_y-45, drift_x+45, drift_y+45, outline=color, width=2, tags="crosshair")
        self.canvas.create_line(drift_x-100, drift_y, drift_x+100, drift_y, fill=color, tags="crosshair")
        self.canvas.create_line(drift_x, drift_y-100, drift_x, drift_y+100, fill=color, tags="crosshair")
        
        # Digital Hud elements
        self.canvas.create_text(drift_x+55, drift_y-55, text=f"AZM:{self.wind_force:+.1f}", fill=color, font=("Courier", 9), tags="crosshair")
        self.canvas.create_text(drift_x+55, drift_y-42, text=f"LVL:{self.level}", fill=color, font=("Courier", 9), tags="crosshair")

    def shoot(self, event):
        if self.is_game_over: return

        self.recoil_offset = 60 # Heavier recoil
        self.root.after(120, self.reset_recoil)

        flash = self.canvas.create_oval(
            event.x-30, event.y-30, event.x+30, event.y+30, 
            fill="#ffff99", outline="white", tags="flash"
        )
        self.root.after(70, lambda: self.canvas.delete(flash))

        sway_x = math.sin(self.frame_count * 0.07) * 7
        sway_y = math.cos(self.frame_count * 0.12) * 4
        target_x = event.x + (self.wind_force * 14) + sway_x
        target_y = event.y + sway_y

        hit_detected = False
        for barrel in self.barrels[:]:
            if (abs(target_x - barrel['x']) < barrel['r'] and 
                abs(target_y - barrel['y']) < barrel['r'] * 1.5):
                
                barrel['hp'] -= 1
                hit_detected = True
                
                if barrel['hp'] <= 0:
                    self.explode(barrel)
                    self.barrels.remove(barrel)
                    self.score += 300 * self.level
                    self.barrels_left -= 1
                else:
                    self.canvas.itemconfig(barrel['id'], fill=self.get_barrel_color(barrel['hp']))
                    self.score += 75
                break
        
        if not hit_detected:
            self.score = max(0, self.score - 150)
        
        if self.barrels_left <= 0:
            self.level += 1
            self.root.after(300, self.start_level)
            
        self.update_ui()

    def reset_recoil(self):
        self.recoil_offset = 0

    def explode(self, barrel):
        self.canvas.delete(barrel['id'])
        for _ in range(25):
            px = barrel['x'] + random.randint(-60, 60)
            py = barrel['y'] + random.randint(-60, 60)
            p = self.canvas.create_rectangle(px-3, py-3, px+3, py+3, fill="#ff4500", outline="#333")
            self.root.after(500, lambda p=p: self.canvas.delete(p))

    def update_ui(self):
        self.canvas.delete("ui")
        
        self.canvas.create_text(25, 25, anchor="nw", text=f"TOTAL SCORE: {self.score}", fill="#ff3300", font=("Courier", 20, "bold"), tags="ui")
        self.canvas.create_text(25, 55, anchor="nw", text=f"BEST RECORD: {self.high_score}", fill="#555", font=("Courier", 13), tags="ui")
        self.canvas.create_text(25, 80, anchor="nw", text=f"SECTOR: {self.level}", fill="#3498db", font=("Courier", 15), tags="ui")
        
        time_color = "white" if self.time_left > 2 else "#ff0000"
        self.canvas.create_text(self.width/2, 25, anchor="n", text=f"RTB IN: {self.time_left:02d}s", fill=time_color, font=("Courier", 32, "bold"), tags="ui")
        
        if self.is_game_over:
            self.save_high_score()
            self.canvas.create_rectangle(0, 0, self.width, self.height, fill="black", stipple="gray75", tags="ui")
            self.canvas.create_text(self.width/2, self.height/2 - 30, text="TERMINATED", fill="#ff0000", font=("Courier", 60, "bold"), tags="ui")
            self.canvas.create_text(self.width/2, self.height/2 + 50, text=f"FINAL SCORE: {self.score}", fill="white", font=("Courier", 22), tags="ui")
            self.canvas.create_text(self.width/2, self.height/2 + 100, text="R TO RETRY | CLOSE TO SAVE", fill="gray", font=("Courier", 14), tags="ui")

    def countdown(self):
        if self.timer_id:
            self.root.after_cancel(self.timer_id)
        
        if not self.is_game_over:
            if self.time_left > 0:
                self.time_left -= 1
                self.update_ui()
                self.timer_id = self.root.after(1000, self.countdown)
            else:
                self.game_over()

    def game_loop(self):
        if self.loop_id:
            self.root.after_cancel(self.loop_id)

        self.update_crosshair()
        
        if not self.is_game_over:
            for s in self.smoke_particles:
                s['x'] += s['dx']
                if s['x'] > self.width + s['size']: s['x'] = -s['size']
                if s['x'] < -s['size']: s['x'] = self.width + s['size']
                self.canvas.coords(s['id'], s['x']-s['size'], s['y']-s['size'], s['x']+s['size'], s['y']+s['size'])

            for b in self.barrels:
                b['phase'] += 0.2
                b['x'] += b['dx']
                b['y'] += b['dy'] + (math.sin(b['phase']) * 4)
                
                # Bouncing makes them faster now
                if b['x'] - b['r'] <= 0 or b['x'] + b['r'] >= self.width: b['dx'] *= -1.08 
                if b['y'] - b['r']*1.5 <= 0 or b['y'] + b['r']*1.5 >= self.height: b['dy'] *= -1.08
                
                b['dx'] = max(-18, min(18, b['dx']))
                b['dy'] = max(-18, min(18, b['dy']))
                
                self.canvas.coords(b['id'], b['x']-b['r'], b['y']-b['r']*1.5, b['x']+b['r'], b['y']+b['r']*1.5)

        self.loop_id = self.root.after(16, self.game_loop)

    def game_over(self):
        self.is_game_over = True
        self.save_high_score()
        self.update_ui()

    def reset_game(self):
        self.save_high_score()
        self.score = 0
        self.level = 1
        self.is_game_over = False
        self.frame_count = 0 # Reset sway
        self.start_level()
        self.countdown()
        # Note: game_loop is already running, so we don't start a new one to avoid speed-ups

if __name__ == "__main__":
    root = tk.Tk()
    root.resizable(False, False)
    game = SniperGame(root)
    root.mainloop()