import tkinter as tk
from tkinter import ttk, messagebox
import time

# ===============================
# Main Window
# ===============================
root = tk.Tk()
root.title("Productivity & Converter Toolkit")
root.geometry("900x600")
root.minsize(750, 500)

# ===============================
# Notebook (Tabs)
# ===============================
notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

notes_tab = ttk.Frame(notebook)
timer_tab = ttk.Frame(notebook)
converter_tab = ttk.Frame(notebook)

notebook.add(notes_tab, text="Notes")
notebook.add(timer_tab, text="Timer")
notebook.add(converter_tab, text="Converters")

# =====================================================
# NOTES TAB
# =====================================================
notes_text = tk.Text(notes_tab, wrap="word")
notes_text.pack(fill="both", expand=True, padx=10, pady=10)

def clear_notes():
    if messagebox.askyesno("Clear Notes", "Delete all notes?"):
        notes_text.delete("1.0", tk.END)

tk.Button(notes_tab, text="Clear Notes", command=clear_notes).pack(pady=5)

# =====================================================
# TIMER TAB (STOPWATCH)
# =====================================================
timer_running = False
start_time = 0

timer_label = tk.Label(timer_tab, text="00:00:00", font=("Arial", 36))
timer_label.pack(pady=20)

def update_timer():
    if timer_running:
        elapsed = int(time.time() - start_time)
        h = elapsed // 3600
        m = (elapsed % 3600) // 60
        s = elapsed % 60
        timer_label.config(text=f"{h:02}:{m:02}:{s:02}")
        root.after(1000, update_timer)

def start_timer():
    global timer_running, start_time
    if not timer_running:
        timer_running = True
        start_time = time.time()
        update_timer()

def stop_timer():
    global timer_running
    timer_running = False

def reset_timer():
    global timer_running
    timer_running = False
    timer_label.config(text="00:00:00")

btn_frame = tk.Frame(timer_tab)
btn_frame.pack()

tk.Button(btn_frame, text="Start", width=10, command=start_timer).pack(side="left", padx=5)
tk.Button(btn_frame, text="Stop", width=10, command=stop_timer).pack(side="left", padx=5)
tk.Button(btn_frame, text="Reset", width=10, command=reset_timer).pack(side="left", padx=5)

# =====================================================
# CONVERTERS TAB
# =====================================================
converter_tabs = ttk.Notebook(converter_tab)
converter_tabs.pack(fill="both", expand=True, padx=10, pady=10)

# -------------------------------
# LENGTH CONVERTER
# -------------------------------
length_tab = ttk.Frame(converter_tabs)
converter_tabs.add(length_tab, text="Length")

length_input = tk.StringVar()
length_output = tk.StringVar()

def convert_length():
    try:
        meters = float(length_input.get())
        feet = meters * 3.28084
        length_output.set(f"{feet:.3f} feet")
    except ValueError:
        length_output.set("Invalid input")

tk.Label(length_tab, text="Meters:").pack(pady=5)
tk.Entry(length_tab, textvariable=length_input).pack()
tk.Button(length_tab, text="Convert → Feet", command=convert_length).pack(pady=5)
tk.Label(length_tab, textvariable=length_output, font=("Arial", 12)).pack(pady=10)

# -------------------------------
# TEMPERATURE CONVERTER
# -------------------------------
temp_tab = ttk.Frame(converter_tabs)
converter_tabs.add(temp_tab, text="Temperature")

temp_input = tk.StringVar()
temp_output = tk.StringVar()

def convert_temp():
    try:
        c = float(temp_input.get())
        f = (c * 9 / 5) + 32
        temp_output.set(f"{f:.2f} °F")
    except ValueError:
        temp_output.set("Invalid input")

tk.Label(temp_tab, text="Celsius:").pack(pady=5)
tk.Entry(temp_tab, textvariable=temp_input).pack()
tk.Button(temp_tab, text="Convert → Fahrenheit", command=convert_temp).pack(pady=5)
tk.Label(temp_tab, textvariable=temp_output, font=("Arial", 12)).pack(pady=10)

# -------------------------------
# IMPROVED TIME CONVERTER
# -------------------------------
time_tab = ttk.Frame(converter_tabs)
converter_tabs.add(time_tab, text="Time")

time_value = tk.StringVar()
time_result = tk.StringVar()

time_units = {
    "Seconds": 1,
    "Minutes": 60,
    "Hours": 3600,
    "Days": 86400
}

from_unit = tk.StringVar(value="Seconds")
to_unit = tk.StringVar(value="Minutes")

def convert_time():
    try:
        value = float(time_value.get())
        seconds = value * time_units[from_unit.get()]
        result = seconds / time_units[to_unit.get()]
        time_result.set(f"{result:.4f} {to_unit.get()}")
    except ValueError:
        time_result.set("Invalid input")

tk.Label(time_tab, text="Value:").pack(pady=5)
tk.Entry(time_tab, textvariable=time_value).pack()

tk.Label(time_tab, text="From:").pack(pady=(10, 0))
ttk.Combobox(
    time_tab,
    textvariable=from_unit,
    values=list(time_units.keys()),
    state="readonly"
).pack()

tk.Label(time_tab, text="To:").pack(pady=(10, 0))
ttk.Combobox(
    time_tab,
    textvariable=to_unit,
    values=list(time_units.keys()),
    state="readonly"
).pack()

tk.Button(time_tab, text="Convert", command=convert_time).pack(pady=15)
tk.Label(time_tab, textvariable=time_result, font=("Arial", 14)).pack(pady=10)

# =====================================================
# STATUS BAR
# =====================================================
status_bar = tk.Label(root, text="Ready", relief="sunken", anchor="w", padx=10)
status_bar.pack(side="bottom", fill="x")

# ===============================
# Run App
# ===============================
root.mainloop()