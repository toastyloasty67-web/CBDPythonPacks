import tkinter as tk
import random
import os
import json
import base64
import time
import getpass
from tkinter import messagebox, filedialog

class MinesweeperGame:
    def __init__(self, master, rows=10, cols=10, mines=15, seed=None):
        self.master = master
        self.master.title("Minesweeper")
        
        self.rows = rows
        self.cols = cols
        self.mines_count = mines
        self.seed = seed if seed is not None else random.randint(0, 999999)
        
        # Game State / Stats
        self.board = [] 
        self.buttons = {}
        self.revealed = set()
        self.flags = set()
        self.game_over = False
        self.start_time = time.time()
        self.tiles_clicked = 0
        self.score = 0

        # Setup Paths
        username = getpass.getuser()
        self.base_path = rf"C:\Users\{username}\Desktop\Minesweeper\Minesweeper"
        self.save_dir = os.path.join(self.base_path, "Save Data")
        self.custom_maps_dir = os.path.join(self.base_path, "Custom Maps")
        self.seeded_maps_dir = os.path.join(self.base_path, "Seeded Maps")
        self.save_filename = "current_game.Minesweep"
        
        # Ensure directories exist
        for d in [self.save_dir, self.custom_maps_dir, self.seeded_maps_dir]:
            if not os.path.exists(d):
                os.makedirs(d, exist_ok=True)
        
        # UI Setup (Classical Style)
        self.main_frame = tk.Frame(self.master, bg="#bdbdbd", bd=3, relief="raised")
        self.main_frame.pack(fill="both", expand=True)
        
        # Top Bar
        self.top_frame = tk.Frame(self.main_frame, bg="#bdbdbd", bd=2, relief="sunken")
        self.top_frame.pack(fill="x", padx=5, pady=5)
        
        self.info_label = tk.Label(self.top_frame, text=f"Seed: {self.seed}", bg="#bdbdbd", font=("Arial", 8))
        self.info_label.pack(side="left", padx=5)
        
        # Buttons
        btn_config = {"font": ("Arial", 8), "bg": "#bdbdbd", "relief": "raised"}
        
        self.docs_btn = tk.Button(self.top_frame, text="Docs", command=self.show_docs, **btn_config)
        self.docs_btn.pack(side="right", padx=2)
        
        self.creator_btn = tk.Button(self.top_frame, text="Map Creator", command=self.open_creator, **btn_config)
        self.creator_btn.pack(side="right", padx=2)

        self.import_btn = tk.Button(self.top_frame, text="Import", command=self.import_game, **btn_config)
        self.import_btn.pack(side="right", padx=2)

        self.save_btn = tk.Button(self.top_frame, text="Save", command=self.save_game, **btn_config)
        self.save_btn.pack(side="right", padx=2)

        # Grid
        self.grid_frame = tk.Frame(self.main_frame, bg="#7b7b7b", bd=3, relief="sunken")
        self.grid_frame.pack(padx=5, pady=5)
        
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.start_new_game()

    def show_docs(self):
        docs = tk.Toplevel(self.master)
        docs.title("Documentation")
        docs.geometry("400x300")
        docs.config(bg="#bdbdbd")
        
        text = (
            "CRYPTIC SYMBOLS GUIDE\n"
            "----------------------\n\n"
            "^ : There is a 50/50 chance a mine is on the tile ABOVE this one.\n\n"
            "V : There is a 50/50 chance a mine is on the tile BELOW this one.\n\n"
            "$ : A mine exists in one of the 4 diagonal corners of this tile.\n\n"
            "@ : A mine exists exactly 2 tiles away (N, S, E, W, or diagonal jump).\n\n"
            "Numbers: Standard count of mines in all 8 adjacent tiles."
        )
        tk.Label(docs, text=text, bg="#bdbdbd", justify="left", font=("Courier", 10), padx=20, pady=20).pack()

    def start_new_game(self):
        random.seed(self.seed)
        self.board = [[False for _ in range(self.cols)] for _ in range(self.rows)]
        count = 0
        while count < self.mines_count:
            r = random.randint(0, self.rows - 1)
            c = random.randint(0, self.cols - 1)
            if not self.board[r][c]:
                self.board[r][c] = True
                count += 1
        self.info_label.config(text=f"Seed: {self.seed}")
        self.create_widgets()

    def create_widgets(self):
        for widget in self.grid_frame.winfo_children():
            widget.destroy()
        self.buttons = {}
        for r in range(self.rows):
            for c in range(self.cols):
                btn = tk.Button(self.grid_frame, width=2, height=1, font=("Courier", 12, "bold"),
                                bg="#bdbdbd", relief="raised", bd=2,
                                command=lambda row=r, col=c: self.on_left_click(row, col))
                btn.bind("<Button-3>", lambda e, row=r, col=c: self.on_right_click(row, col))
                btn.grid(row=r, column=c)
                self.buttons[(r, c)] = btn
        for r, c in self.revealed: self.apply_reveal_ui(r, c)
        for r, c in self.flags: self.buttons[(r, c)].config(text="P", fg="red")

    def get_cryptic_symbol(self, r, c):
        # We use a sub-seed here based on coordinates + global seed to keep symbols consistent
        rng = random.Random(f"{self.seed}-{r}-{c}")
        if r > 0 and self.board[r-1][c] and rng.random() < 0.5: return "^"
        if r < self.rows - 1 and self.board[r+1][c] and rng.random() < 0.5: return "V"
        diagonals = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
        for dr, dc in diagonals:
            nr, nc = r + dr, c + dc
            if 0 <= nr < self.rows and 0 <= nc < self.cols and self.board[nr][nc]: return "$"
        steps = [(-2,0),(2,0),(0,-2),(0,2),(-2,-2),(-2,2),(2,-2),(2,2)]
        for dr, dc in steps:
            nr, nc = r + dr, c + dc
            if 0 <= nr < self.rows and 0 <= nc < self.cols and self.board[nr][nc]: return "@"
        return None

    def on_left_click(self, r, c):
        if self.game_over or (r, c) in self.flags or (r, c) in self.revealed: return
        self.tiles_clicked += 1
        if self.board[r][c]:
            self.trigger_game_over(False)
            return
        self.reveal_tile(r, c)
        self.score += 10
        if len(self.revealed) == (self.rows * self.cols) - self.mines_count: self.trigger_game_over(True)

    def on_right_click(self, r, c):
        if self.game_over or (r, c) in self.revealed: return
        btn = self.buttons[(r, c)]
        if (r, c) in self.flags:
            self.flags.remove((r, c))
            btn.config(text="", bg="#bdbdbd")
        else:
            self.flags.add((r, c))
            btn.config(text="P", fg="red")

    def reveal_tile(self, r, c):
        if (r, c) in self.revealed: return
        self.revealed.add((r, c))
        self.apply_reveal_ui(r, c)
        count = self.count_adj(r, c)
        if count == 0 and not self.get_cryptic_symbol(r, c):
            for dr in [-1,0,1]:
                for dc in [-1,0,1]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < self.rows and 0 <= nc < self.cols: self.reveal_tile(nr, nc)

    def count_adj(self, r, c):
        count = 0
        for dr in [-1,0,1]:
            for dc in [-1,0,1]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < self.rows and 0 <= nc < self.cols and self.board[nr][nc]: count += 1
        return count

    def apply_reveal_ui(self, r, c):
        btn = self.buttons[(r, c)]
        count = self.count_adj(r, c)
        cryptic = self.get_cryptic_symbol(r, c)
        btn.config(relief="sunken", bg="#d9d9d9", state="disabled")
        if count > 0:
            colors = ["", "blue", "green", "red", "darkblue", "darkred", "teal", "black", "gray"]
            btn.config(text=str(count), disabledforeground=colors[min(count, 8)])
        elif cryptic:
            btn.config(text=cryptic, disabledforeground="purple")
        else:
            btn.config(text="")

    def encrypt_data(self, data_dict):
        raw_json = json.dumps(data_dict)
        key = "SECRET_MINESWEEPER_KEY"
        encrypted = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(raw_json))
        return base64.b64encode(encrypted.encode()).decode()

    def decrypt_data(self, encoded_str):
        decoded = base64.b64decode(encoded_str).decode()
        key = "SECRET_MINESWEEPER_KEY"
        decrypted = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(decoded))
        return json.loads(decrypted)

    def save_game(self, silent=False):
        data = {
            "seed": self.seed, "tiles_clicked": self.tiles_clicked, "score": self.score,
            "revealed": [list(item) for item in self.revealed],
            "flags": [list(item) for item in self.flags],
            "rows": self.rows, "cols": self.cols, "mines": self.mines_count
        }
        try:
            filepath = os.path.join(self.save_dir, self.save_filename)
            with open(filepath, "w") as f: f.write(self.encrypt_data(data))
            if not silent: messagebox.showinfo("Saved", "Game progress updated.")
        except Exception as e:
            if not silent: messagebox.showerror("Error", f"Could not save: {e}")

    def import_game(self):
        try:
            filepath = filedialog.askopenfilename(initialdir=self.base_path, title="Import Save/Map",
                                                  filetypes=(("Minesweep/SED files", "*.Minesweep *.SED"), ("all files", "*.*")))
            if not filepath: return
            with open(filepath, "r") as f: encoded = f.read()
            data = self.decrypt_data(encoded)
            self.seed, self.tiles_clicked, self.score = data["seed"], data["tiles_clicked"], data["score"]
            self.rows, self.cols, self.mines_count = data["rows"], data["cols"], data["mines"]
            self.revealed = set(tuple(x) for x in data.get("revealed", []))
            self.flags = set(tuple(x) for x in data.get("flags", []))
            self.game_over = False
            self.start_new_game()
        except Exception as e: messagebox.showerror("Import Error", f"Failed: {e}")

    def on_closing(self):
        self.save_game(silent=True)
        self.master.destroy()

    def trigger_game_over(self, won):
        self.game_over = True
        for (r, c), btn in self.buttons.items():
            if self.board[r][c]: btn.config(text="*", bg="red" if not won else "green", state="disabled")
            else: btn.config(state="disabled")
        messagebox.showinfo("Result", f"{'You Won!' if won else 'Game Over!'}\nScore: {self.score}")

    def open_creator(self):
        CreatorWindow(self.master, self)

class CreatorWindow:
    def __init__(self, parent, game_ref):
        self.window = tk.Toplevel(parent)
        self.window.title("Tilemap Creator")
        self.window.config(bg="#bdbdbd")
        self.game_ref = game_ref
        
        self.mode = "Unruled" # Unruled or Ruled
        self.selected_tile = "Mine" # Mine, ^, V, $, @
        self.custom_board = [["" for _ in range(10)] for _ in range(10)]
        self.buttons = {}
        
        # Toolbar
        self.toolbar = tk.Frame(self.window, bg="#bdbdbd", bd=2, relief="raised")
        self.toolbar.pack(fill="x", padx=5, pady=5)
        
        self.mode_btn = tk.Button(self.toolbar, text="Mode: Unruled", command=self.toggle_mode, font=("Arial", 8))
        self.mode_btn.pack(side="left", padx=5)
        
        tk.Label(self.toolbar, text="Select Tile:", bg="#bdbdbd", font=("Arial", 8)).pack(side="left", padx=5)
        self.tile_var = tk.StringVar(value="Mine")
        for t in ["Mine", "^", "V", "$", "@", "Empty"]:
            tk.Radiobutton(self.toolbar, text=t, variable=self.tile_var, value=t, bg="#bdbdbd", font=("Arial", 8)).pack(side="left")

        # Removed .SED Save Button as per request
        tk.Button(self.toolbar, text="Save .Tilemap", command=self.save_tilemap, font=("Arial", 8)).pack(side="right", padx=2)

        self.grid_frame = tk.Frame(self.window, bg="#7b7b7b", bd=3, relief="sunken")
        self.grid_frame.pack(padx=10, pady=10)
        
        self.create_grid()

    def toggle_mode(self):
        self.mode = "Ruled" if self.mode == "Unruled" else "Unruled"
        self.mode_btn.config(text=f"Mode: {self.mode}")

    def create_grid(self):
        for r in range(10):
            for c in range(10):
                btn = tk.Button(self.grid_frame, width=2, height=1, font=("Courier", 12, "bold"),
                                bg="#bdbdbd", relief="raised", command=lambda row=r, col=c: self.place_tile(row, col))
                btn.grid(row=r, column=c)
                self.buttons[(r, c)] = btn

    def place_tile(self, r, c):
        val = self.tile_var.get()
        if val == "Empty": val = ""
        
        if self.mode == "Ruled":
            # In ruled mode, logic for placement constraints could go here
            pass
            
        self.custom_board[r][c] = val
        display = "*" if val == "Mine" else val
        self.buttons[(r, c)].config(text=display, fg="black" if val != "Mine" else "red")

    def save_tilemap(self):
        """Unencrypted save for custom manual maps."""
        data = {"board": self.custom_board, "type": "custom_tilemap"}
        path = os.path.join(self.game_ref.custom_maps_dir, f"map_{int(time.time())}.Tilemap")
        try:
            with open(path, "w") as f: json.dump(data, f)
            messagebox.showinfo("Saved", f"Tilemap saved to Custom Maps.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save tilemap: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    game = MinesweeperGame(root)
    root.mainloop()