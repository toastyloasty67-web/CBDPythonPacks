import tkinter as tk
from tkinter import messagebox

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calc")
        self.root.geometry("350x550")
        self.history = [] 

        self.colors = {
            "bg": "#2c3e50", "display_bg": "#34495e", "text": "#ecf0f1",
            "btn_default": "#95a5a6", "btn_op": "#e67e22", "btn_hist": "#3498db"
        }
        self.root.config(bg=self.colors["bg"])
        self.create_widgets()

    def create_widgets(self):
        self.entry = tk.Entry(self.root, font=("Arial", 28), bg=self.colors["display_bg"], 
                              fg=self.colors["text"], justify='right', borderwidth=0)
        self.entry.grid(row=0, column=0, columnspan=4, padx=10, pady=30, sticky="nsew")

        button_map = [
            ('C', 1, 0, "btn_default"), ('/', 1, 1, "btn_op"), ('*', 1, 2, "btn_op"), ('History', 1, 3, "btn_hist"),
            ('7', 2, 0, "btn_default"), ('8', 2, 1, "btn_default"), ('9', 2, 2, "btn_default"), ('-', 2, 3, "btn_op"),
            ('4', 3, 0, "btn_default"), ('5', 3, 1, "btn_default"), ('6', 3, 2, "btn_default"), ('+', 3, 3, "btn_op"),
            ('1', 4, 0, "btn_default"), ('2', 4, 1, "btn_default"), ('3', 4, 2, "btn_default"), ('=', 4, 3, "btn_op"),
            ('0', 5, 0, "btn_default"), ('.', 5, 1, "btn_default"),
        ]

        for (text, r, c, col_key) in button_map:
            col_span = 2 if text == '0' else 1
            tk.Button(self.root, text=text, font=("Arial", 12, "bold"), bg=self.colors[col_key], 
                      fg="white", relief="flat", command=lambda t=text: self.handle_click(t)
            ).grid(row=r, column=c, columnspan=col_span, padx=5, pady=5, sticky="nsew")

        for i in range(4): self.root.grid_columnconfigure(i, weight=1)
        for i in range(1, 6): self.root.grid_rowconfigure(i, weight=1)

    def handle_click(self, char):
        if char == "C": self.entry.delete(0, tk.END)
        elif char == "History": self.show_history()
        elif char == "=": self.calculate()
        else: self.entry.insert(tk.END, char)

    def calculate(self):
        equation = self.entry.get()
        try:
            result = eval(equation)
            self.history.append(f"{equation} = {result}")
            self.entry.delete(0, tk.END)
            self.entry.insert(tk.END, str(result))
        except:
            messagebox.showerror("Error", "Invalid Math")

    def show_history(self):
        hist_window = tk.Toplevel(self.root)
        hist_window.title("Logs")
        hist_window.geometry("300x400")

        tk.Label(hist_window, text="Right-click an entry for options", font=("Arial", 9, "italic")).pack(pady=5)

        listbox = tk.Listbox(hist_window, font=("Arial", 12), width=30, height=15)
        listbox.pack(padx=10, pady=10, fill="both", expand=True)

        for item in self.history:
            listbox.insert(tk.END, item)

        # --- Context Menu Logic ---
        menu = tk.Menu(hist_window, tearoff=0)

        def do_load():
            selection = listbox.get(listbox.curselection())
            self.entry.delete(0, tk.END)
            self.entry.insert(tk.END, selection.split("=")[0].strip())
            hist_window.destroy()

        def do_delete():
            idx = listbox.curselection()
            if idx:
                self.history.pop(idx[0])
                listbox.delete(idx[0])

        menu.add_command(label="Load into Calculator", command=do_load)
        menu.add_command(label="Delete Log", command=do_delete)

        def show_menu(event):
            # Select the item under the mouse first
            listbox.selection_clear(0, tk.END)
            listbox.selection_set(listbox.nearest(event.y))
            listbox.activate(listbox.nearest(event.y))
            # Display the menu at mouse coordinates
            menu.post(event.x_root, event.y_root)

        # Bind Right-Click (Windows/Linux use <Button-3>, macOS uses <Button-2>)
        listbox.bind("<Button-3>", show_menu) 
        listbox.bind("<Button-2>", show_menu) # For Mac users

# --- Run ---
if __name__ == "__main__":
    root = tk.Tk()
    Calculator(root)
    root.mainloop()