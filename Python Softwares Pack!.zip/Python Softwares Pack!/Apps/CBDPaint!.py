import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
import random
import os
import math
import json

class CBDPaint:
    def __init__(self, root):
        self.root = root
        self.root.title("CBDPaint")
        self.root.geometry("1150x850")
        self.root.configure(bg="#050505")

        # --- Path Logic ---
        user_name = os.getlogin()
        self.asset_path = rf"C:\Users\{user_name}\Desktop\Python Softwares Pack!\Assets\pixil-frame-0.png"

        # --- State Variables ---
        self.current_color = "#00FFCC"
        self.brush_shape = tk.StringVar(value="Circle")
        self.trail_speed = tk.DoubleVar(value=0.02)
        self.particles = []

        self.setup_main_ui()
        self.setup_splash_screen()
        self.animate_particles()

    def setup_main_ui(self):
        # --- Toolbar ---
        toolbar = tk.Frame(self.root, bg="#111", width=250)
        toolbar.pack(side="left", fill="y", padx=5, pady=5)

        tk.Label(toolbar, text="CBD PAINT", fg="#00FFCC", bg="#111", font=("Impact", 28)).pack(pady=20)
        
        # 1. Color Selection
        self.color_preview = tk.Frame(toolbar, bg=self.current_color, height=40)
        self.color_preview.pack(fill="x", padx=20, pady=5)
        tk.Button(toolbar, text="SELECT COLOR", bg="#222", fg="white", relief="flat",
                  command=self.choose_color).pack(fill="x", padx=20, pady=5)

        # 2. Size Modifier
        tk.Label(toolbar, text="BRUSH SIZE", fg="gray", bg="#111", font=("Arial", 10)).pack(pady=(15, 0))
        self.size_slider = tk.Scale(toolbar, from_=2, to=100, orient="horizontal", 
                                    bg="#111", fg="white", highlightthickness=0)
        self.size_slider.set(15)
        self.size_slider.pack(fill="x", padx=20)

        # 3. Shape Selector
        tk.Label(toolbar, text="BRUSH SHAPE", fg="gray", bg="#111", font=("Arial", 10)).pack(pady=(15, 0))
        shape_frame = tk.Frame(toolbar, bg="#111")
        shape_frame.pack(pady=5)
        for shape in ["Circle", "Square", "Star"]:
            tk.Radiobutton(shape_frame, text=shape, variable=self.brush_shape, value=shape,
                           bg="#222", fg="white", selectcolor="#00FFCC", indicatoron=0, 
                           width=8).pack(side="left", padx=2)

        # --- Data Buttons ---
        tk.Button(toolbar, text="💾 SAVE OPTIONS", bg="#27ae60", fg="white", font=("Arial", 10, "bold"),
                  relief="flat", command=self.open_save_screen).pack(pady=(20, 5), fill="x", padx=20)
        
        tk.Button(toolbar, text="📂 IMPORT .CBD", bg="#8e44ad", fg="white", font=("Arial", 10, "bold"),
                  relief="flat", command=self.import_cbd).pack(pady=5, fill="x", padx=20)

        # Info & Clear
        tk.Button(toolbar, text="ⓘ APP INFO", bg="#3498db", fg="white", font=("Arial", 10, "bold"),
                  relief="flat", command=self.open_info).pack(pady=10, fill="x", padx=20)

        tk.Button(toolbar, text="CLEAR CANVAS", bg="#ff4444", fg="white", font=("Arial", 10, "bold"),
                  relief="flat", command=self.clear_canvas).pack(side="bottom", fill="x", padx=20, pady=20)

        # --- Drawing Canvas ---
        self.canvas = tk.Canvas(self.root, bg="black", highlightthickness=0)
        self.canvas.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        self.canvas.bind("<B1-Motion>", self.spawn)
        self.canvas.bind("<Button-1>", self.spawn)

    # --- New Save/Import Logic ---
    def open_save_screen(self):
        """Custom Save Confirmation Screen."""
        save_win = tk.Toplevel(self.root)
        save_win.title("Export Settings")
        save_win.geometry("400x200")
        save_win.configure(bg="#111")
        save_win.resizable(False, False)

        tk.Label(save_win, text="THIS WILL BECOME A .CBD TO SAVE DATA!", 
                 fg="#f1c40f", bg="#111", font=("Arial", 11, "bold")).pack(pady=30)

        btn_frame = tk.Frame(save_win, bg="#111")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="please download", bg="#27ae60", fg="white", width=15,
                  command=lambda: [save_win.destroy(), self.save_cbd()]).pack(side="left", padx=10)
        
        tk.Button(btn_frame, text="Nah", bg="#c0392b", fg="white", width=10,
                  command=save_win.destroy).pack(side="left", padx=10)

    def save_cbd(self):
        """Saves current settings to a .cbd file."""
        data = {
            "color": self.current_color,
            "size": self.size_slider.get(),
            "shape": self.brush_shape.get()
        }
        file_path = filedialog.asksaveasfilename(defaultextension=".cbd", 
                                                 filetypes=[("CBD Data", "*.cbd")])
        if file_path:
            with open(file_path, 'w') as f:
                json.dump(data, f)
            messagebox.showinfo("Success", "Settings saved as .cbd!")

    def import_cbd(self):
        """Loads settings from a .cbd file."""
        file_path = filedialog.askopenfilename(filetypes=[("CBD Data", "*.cbd")])
        if file_path:
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                # Apply data
                self.current_color = data["color"]
                self.color_preview.config(bg=self.current_color)
                self.size_slider.set(data["size"])
                self.brush_shape.set(data["shape"])
                messagebox.showinfo("Loaded", "Settings imported successfully!")
            except Exception as e:
                messagebox.showerror("Error", "Invalid .CBD file.")

    # --- Rest of the App Logic ---
    def setup_splash_screen(self):
        self.splash = tk.Canvas(self.root, bg="#000", highlightthickness=0)
        self.splash.place(x=0, y=0, relwidth=1, relheight=1)
        if os.path.exists(self.asset_path):
            try:
                self.logo = tk.PhotoImage(file=self.asset_path)
                self.splash.create_image(575, 425, image=self.logo)
            except: pass
        self.root.after(1200, self.splash.destroy)

    def open_info(self):
        info_win = tk.Toplevel(self.root)
        info_win.title("About CBDPaint")
        info_win.geometry("400x250")
        info_win.configure(bg="#111")
        tk.Label(info_win, text="CREDITS", fg="#00FFCC", bg="#111", font=("Impact", 20)).pack(pady=10)
        tk.Label(info_win, text="\nThis Program was made by CBD!\n\nOr Christmas Big Dih on discord", 
                 fg="white", bg="#111", font=("Arial", 12)).pack(pady=10)

    def choose_color(self):
        color = colorchooser.askcolor(title="CBDPaint Palette")[1]
        if color:
            self.current_color = color
            self.color_preview.config(bg=color)

    def clear_canvas(self):
        self.canvas.delete("all")
        self.particles = []

    def draw_star(self, x, y, size, color):
        points = []
        for i in range(10):
            angle = math.radians(i * 36)
            r = size if i % 2 == 0 else size // 2
            points.extend([x + r * math.cos(angle), y + r * math.sin(angle)])
        return self.canvas.create_polygon(points, fill=color, outline="")

    def spawn(self, event):
        size = self.size_slider.get()
        shape = self.brush_shape.get()
        for _ in range(2):
            vx, vy = random.uniform(-3, 3), random.uniform(-3, 3)
            if shape == "Circle":
                p_id = self.canvas.create_oval(event.x, event.y, event.x+size, event.y+size, fill=self.current_color, outline="")
            elif shape == "Square":
                p_id = self.canvas.create_rectangle(event.x, event.y, event.x+size, event.y+size, fill=self.current_color, outline="")
            else:
                p_id = self.draw_star(event.x, event.y, size/2, self.current_color)
            self.particles.append({'id': p_id, 'vx': vx, 'vy': vy, 'life': 1.0})

    def animate_particles(self):
        new_particles = []
        for p in self.particles:
            self.canvas.move(p['id'], p['vx'], p['vy'])
            p['life'] -= self.trail_speed.get()
            if p['life'] > 0:
                new_particles.append(p)
            else:
                self.canvas.delete(p['id'])
        self.particles = new_particles
        self.root.after(16, self.animate_particles)

if __name__ == "__main__":
    root = tk.Tk()
    app = CBDPaint(root)
    root.mainloop()